package com.example.bstud11;

import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;

class LocalContentWebViewClient extends WebViewClientCompat {
    private final WebViewAssetLoader assetLoader;
    LocalContentWebViewClient(WebViewAssetLoader webViewAssetLoader) {
        assetLoader = webViewAssetLoader;
    }

    @Override
    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        return assetLoader.shouldInterceptRequest(request.getUrl());
    }
}
public class MainActivity extends AppCompatActivity {
    WebView webView;
    WebViewAssetLoader webViewAssetLoader;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        webViewAssetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/res/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new LocalContentWebViewClient(webViewAssetLoader));
        webView.loadUrl("https://google.com/search?q=android");
    }
}