package com.example.cstud3;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {
    RelativeLayout ball;
    Button movBtn, flipBtn;
    int x = 210;
    boolean isFlip = false, isZoom = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ball = findViewById(R.id.ball);
        movBtn = findViewById(R.id.movBtn);
        flipBtn = findViewById(R.id.flipBtn);
        movBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator animator;
                if (!isFlip) {
                    animator = ObjectAnimator.ofFloat(ball, "translationX",x, x+20);
                    x += 20;
                }
                else {
                    animator = ObjectAnimator.ofFloat(ball, "translationX",x, x-20);
                    x -= 20;
                }
                animator.setDuration(500);
                animator.start();
            }
        });
        flipBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator animator;
                if (!isFlip) {
                    animator = ObjectAnimator.ofFloat(ball, "rotationY", 0, 180);
                }
                else {
                    animator = ObjectAnimator.ofFloat(ball, "rotationY", 180, 0);
                }
                animator.setDuration(500);
                animator.start();
                isFlip = !isFlip;
            }
        });
        ball.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isZoom) {
                    ball.setScaleX(1.1f);
                    ball.setScaleY(1.1f);
                }
                else {
                    ball.setScaleX(0.9f);
                    ball.setScaleY(0.9f);
                }
                isZoom = !isZoom;
            }
        });
    }
}