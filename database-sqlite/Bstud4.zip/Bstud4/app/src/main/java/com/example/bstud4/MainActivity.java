package com.example.bstud4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button insViewBtn;
    private Button selViewBtn;
    private Button delViewBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        insViewBtn = (Button)findViewById(R.id.insViewBtn);
        insViewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, InsActivity.class);
                startActivity(i);
            }
        });

        selViewBtn = (Button)findViewById(R.id.selViewBtn);
        selViewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, SelActivity.class);
                startActivity(i);
            }
        });

        delViewBtn = (Button)findViewById(R.id.delViewBtn);
        delViewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, DelActivity.class);
                startActivity(i);
            }
        });
    }
}