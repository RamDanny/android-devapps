package com.example.bstud4;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DelActivity extends AppCompatActivity {
    private EditText id, sel1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_del);

        Button submitDelBtn = findViewById(R.id.submitDelBtn);
        submitDelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView tv4 = findViewById(R.id.tv4);
                id = findViewById(R.id.del1);
                String idstr = id.getText().toString();
                String rec = "";

                DbMgr dbm = new DbMgr(getApplicationContext());
                Boolean flag = dbm.delete_record(idstr);
                if (flag) {
                    tv4.setText("Deleted!");
                    Intent i = new Intent(DelActivity.this, MainActivity.class);
                    startActivity(i);
                }
                else {
                    tv4.setText("ERROR");
                }
            }
        });
    }
}
