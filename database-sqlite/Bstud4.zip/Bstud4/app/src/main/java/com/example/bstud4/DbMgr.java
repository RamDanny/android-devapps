package com.example.bstud4;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbMgr extends SQLiteOpenHelper {
    public DbMgr(@Nullable Context context) {
        super(context, "mydb.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE tbl(" +
                "id TEXT," +
                "name TEXT," +
                "num TEXT)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public Boolean insert_record(String id, String name, String num) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("id", id);
        cv.put("name", name);
        cv.put("num", num);
        Long result = db.insert("tbl", null, cv);
        if (result != -1) return true;
        else return false;
    }

    public Cursor select_record(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor record = db.rawQuery("SELECT * FROM tbl WHERE id=?", new String[]{id});
        return record;
    }

    public Boolean delete_record(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor record = db.rawQuery("SELECT * FROM tbl WHERE id=?", new String[]{id});
        if (record.getCount() > 0) {
            int result = db.delete("tbl", "id = ?", new String[]{id});
            if (result != -1) return true;
            else return false;
        }
        return false;
    }
}
