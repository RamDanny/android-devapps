package com.example.bstud4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class InsActivity extends AppCompatActivity {
    private EditText id, name, num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ins);

        id = findViewById(R.id.ins1);
        name = findViewById(R.id.ins2);
        num = findViewById(R.id.ins3);
        String idstr, namestr, numstr;

        Button submitInsButton = findViewById(R.id.submitInsBtn);
        submitInsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String idstr = id.getText().toString();
                String namestr = name.getText().toString();
                String numstr = num.getText().toString();
                DbMgr dbm = new DbMgr(getApplicationContext());
                Boolean flag = dbm.insert_record(idstr, namestr, numstr);
                if (flag == true) {
                    Intent i = new Intent(InsActivity.this, MainActivity.class);
                    startActivity(i);
                }
                else {

                }
            }
        });
    }
}
