package com.example.bstud4;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SelActivity extends AppCompatActivity {
    private EditText id, sel1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sel);

        Button submitSelBtn = findViewById(R.id.submitSelBtn);
        submitSelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView tv3 = findViewById(R.id.tv3);
                id = findViewById(R.id.sel1);
                String idstr = id.getText().toString();
                String rec = "";

                DbMgr dbm = new DbMgr(getApplicationContext());
                Cursor record = dbm.select_record(idstr);
                if (record.getCount() != 1) {
                    tv3.setText("ERROR");
                }
                else {
                    while (record.moveToNext()) {
                        rec += "id: " + record.getString(0) + "\n";
                        rec += "name: " + record.getString(1) + "\n";
                        rec += "num: " + record.getString(2) + "\n";
                    }
                    tv3.setText(rec);
                }
            }
        });
    }
}
