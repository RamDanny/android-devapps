package com.example.cstud8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    EditText fileName, fileContent, filName;
    TextView filContent;
    Button writeBtn, readBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fileName = findViewById(R.id.fileName);
        fileContent = findViewById(R.id.fileContent);
        filName = findViewById(R.id.filName);
        filContent = findViewById(R.id.filContent);
        writeBtn = findViewById(R.id.writeBtn);
        readBtn = findViewById(R.id.readBtn);

        writeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    write(view);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        readBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    read(view);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    public void write(View v) throws Exception {
        File path = getApplicationContext().getFilesDir();
        FileOutputStream writer = new FileOutputStream(new File(path, fileName.getText().toString()));
        writer.write(fileContent.getText().toString().getBytes());
        writer.close();
        Toast.makeText(this, "Write Success", Toast.LENGTH_SHORT).show();
    }

    public void read(View v) throws Exception {
        File path = getApplicationContext().getFilesDir();
        File file = new File(path, filName.getText().toString());
        FileInputStream reader = new FileInputStream(file);
        byte[] buffer = new byte[(int)(file.length())];
        reader.read(buffer);
        filContent.setText(new String(buffer));
        Toast.makeText(this, "Read Success", Toast.LENGTH_SHORT).show();
    }
}
