package com.example.cstud6;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListAdapter;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText latit, longit, addr;
    TextView address, latitude, longitude;
    Button getBtn, findBtn, curBtn;
    LocationManager locationManager;
    LocationListener locationListener;
    Geocoder geocoder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addr = findViewById(R.id.addr);
        latit = findViewById(R.id.latit);
        longit = findViewById(R.id.longit);
        address = findViewById(R.id.address);
        latitude = findViewById(R.id.latitude);
        longitude = findViewById(R.id.longitude);
        geocoder = new Geocoder(this);
        getBtn = findViewById(R.id.getBtn);
        findBtn = findViewById(R.id.findBtn);
        curBtn = findViewById(R.id.curBtn);
        curBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
                locationListener = new LocationListener() {
                    @Override
                    public void onLocationChanged(Location location) {
                        latitude.setText(location.getLatitude() + "");
                        longitude.setText(location.getLongitude() + "");
                    }
                };
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
            }
        });
        getBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String adr = addr.getText().toString();
                try {
                    List<Address> addressList = geocoder.getFromLocationName(adr, 1);
                    Address location = addressList.get(0);
                    latitude.setText(location.getLatitude()+"");
                    longitude.setText(location.getLongitude()+"");
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        findBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double lat = Float.parseFloat(latit.getText().toString());
                double lon = Float.parseFloat(longit.getText().toString());
                try {
                    List<Address> addressList = geocoder.getFromLocation(lat, lon, 1);
                    address.setText(addressList.get(0).toString());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }
    public void getCurrent() throws Exception {

    }
}