package com.example.dstud5;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tv1, tv2;
    Button startBtn, pauseBtn;
    String[] colors = {"#ff0000", "#00ff00", "#0000ff"};
    int colori = 0, casei = 0;
    Thread th1, th2;
    Handler h1 = new Handler(Looper.getMainLooper()), h2 = new Handler(Looper.getMainLooper());
    boolean isth = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
        startBtn = findViewById(R.id.startBtn);
        pauseBtn = findViewById(R.id.pauseBtn);
        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isth = true;
                th1 = new Thread(() -> {
                    while (isth) {
                        h1.post(() -> {
                            colori = (colori + 1) % 3;
                            tv1.setTextColor(Color.parseColor(colors[colori]));
                        });
                    }
                });
                th1.start();
                th2 = new Thread(() -> {
                    while (isth) {
                        h2.post(() -> {
                            String str = (String) tv2.getText();
                            casei = (casei + 1) % str.length();
                            str = str.substring(0, casei) + Character.toUpperCase(str.charAt(casei)) + str.substring(casei+1);
                            tv2.setText(str);
                        });
                    }
                });
                th2.start();
            }
        });
        pauseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isth = false;
            }
        });
    }
}