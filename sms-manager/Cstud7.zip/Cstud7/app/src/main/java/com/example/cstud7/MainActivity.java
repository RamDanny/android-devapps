package com.example.cstud7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText smsText, smsNumber;
    Button smsBtn;

    private BroadcastReceiver smsReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                Object[] pdus = (Object[]) bundle.get("pdus");
                if (pdus != null) {
                    for (Object pdu : pdus) {
                        SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) pdu);
                        String senderNumber = smsMessage.getOriginatingAddress();
                        String message = smsMessage.getMessageBody();

                        // Handle the received SMS, e.g., display a Toast
                        Toast.makeText(MainActivity.this, "Received SMS from " + senderNumber + ": " + message, Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        smsText = findViewById(R.id.smsText);
        smsNumber = findViewById(R.id.smsNumber);
        smsBtn = findViewById(R.id.smsBtn);

        // Register SMS Receiver
        registerReceiver(smsReceiver, new IntentFilter("android.provider.Telephony.SMS_RECEIVED"));

        smsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = smsNumber.getText().toString();
                String text = smsText.getText().toString();

                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(number, null, text, null, null);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Unregister the SMS Receiver
        unregisterReceiver(smsReceiver);
    }
}
